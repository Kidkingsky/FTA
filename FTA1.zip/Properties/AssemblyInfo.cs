using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 組件的一般資訊是由下列的屬性集控制。
// 變更這些屬性的值即可修改組件的相關資訊。
[assembly: AssemblyTitle("FTA")]
[assembly: AssemblyDescription("臺灣ECA/FTA總入口網站")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("經濟部國際貿易署")]
[assembly: AssemblyProduct("FTA")]
[assembly: AssemblyCopyright("Copyright © 經濟部國際貿易署 2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 將 ComVisible 設定為 false 會使得這個組件中的類型
// 對 COM 元件而言為不可見。如果您需要從 COM 存取這個組件中的類型，
// 請在該類型上將 ComVisible 屬性設定為 true。
[assembly: ComVisible(false)]

// 下列 GUID 為專案公開 (Expose) 至 COM 時所要使用的 typelib ID
[assembly: Guid("8c5f5e5e-1a2b-4c3d-9e4f-5a6b7c8d9e0f")]

// 組件的版本資訊由下列四個值所組成:
//
//      主要版本
//      次要版本
//      組建編號
//      修訂編號
//
// 您可以指定所有的值，也可以使用 '*' 將組建和修訂編號
// 指定為預設值，如下所示:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
